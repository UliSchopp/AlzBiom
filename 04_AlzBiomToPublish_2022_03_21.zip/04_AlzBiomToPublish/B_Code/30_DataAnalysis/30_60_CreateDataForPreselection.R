library(tidyverse)
library(data.table)
library(Hmisc)
library(xtable)
library(moments)

#########################################################################
#                                                                       #
#         Creation of a table with information on data                  #
#         ============================================                  #
# This information will be used later for pre-selection of features.    #      
# The input data are normalized training data.                          #
# Mind that the p-value of Wilcoxon's test is used for sieving.         #
#########################################################################

# A. Set the working directory here:
setwd("D:/Arbeit/C_KlinischeStudien/04_AlzBiom")

# B. The code for prepartion of the tables is wraped in a function. 
# The only parameter of this function is the input data file's name.

make_Wilconxon_Table <- function(normalisedData = "normalised_training_genus"){
  
  # C. As data table are large, fread function is applied.
  
  Data_Normalisiert <-  
    fread(
      paste("A_Data/02_1_ExtendedTrainingData/",normalisedData,
            ".csv",
            sep = ""),
          header = T, 
      stringsAsFactors = F)
  
  # D. Now data are re-arranged from 'wide' to 'long' format. 
  # This is only a technical matter. In a former version of the code, 
  # we provided the data for some plots.
  # As there are so many features in the data, we then decided to delete this 
  # from the code. But the re-arrangement of data still exists.  
  
  Data_reshaped <- reshape2::melt(Data_Normalisiert, 
                                  id = "outcome")
  Data_reshaped$variable <- as.vector(Data_reshaped$variable)
  
  # E. Only features should enter the Wilcoxon test...  
  non_features <- 
    c("id",
      "DNAID",
      "Viruses",
      "cannot.be.assigned.to.a.phylum",
      "cannot.be.assigned.to.a.genus",
      "cannot.be.assigned.to.a.specie",
      "unclassified",
      "outcome",
      "Age",
      "Sex",
      "BMI",
      "imp_BMI",
      "APOE4",
      "imp_APOE4",
      "BMI Baseline")
  
  feature_names      <- 
    colnames(Data_Normalisiert)[which(colnames(Data_Normalisiert) %nin% non_features)]
  number_of_features <- length(feature_names)
  
  # F. Preparation of a result table for the output.    
  result_table       <- data.frame(matrix(ncol = 15, 
                                          nrow = number_of_features))
  
  Indices_0_Group <- which(Data_Normalisiert$outcome == 0)
  Indices_1_Group <- which(Data_Normalisiert$outcome == 1)
  
  # G. Running through the features...   
  for(i in 1:number_of_features){
    print(i)
    result_table[i,1] <- feature_names[i]
    
    x <- 
      as.numeric(filter(Data_reshaped, 
                        variable == feature_names[i] & outcome == 0)$value)
    y <- 
      as.numeric(filter(Data_reshaped, 
                        variable == feature_names[i] & outcome == 1)$value)
    z <- 
      as.numeric(filter(Data_reshaped, 
                        variable == feature_names[i])$value)
    
    result_table[i,2] <- 
      round(wilcox.test(x, y,
                        alternative = "two.sided")$p.value,5)
    
    nr_outliers_x <- length(boxplot.stats(log10(x))$out)
    nr_outliers_y <- length(boxplot.stats(log10(y))$out)
    result_table[i,3] <- min(nr_outliers_x, nr_outliers_y)
    result_table[i,4] <- max(nr_outliers_x, nr_outliers_y)
    result_table[i,5] <- nr_outliers_x 
    result_table[i,6] <- nr_outliers_y 
    result_table[i,7] <- median(x)
    result_table[i,8] <- median(y)
    result_table[i,9] <- median(z)
    result_table[i,10] <- IQR(log(x))
    result_table[i,11] <- IQR(log(y))
    result_table[i,12] <- IQR(log(z))
    result_table[i,13] <- sum(nr_outliers_x + nr_outliers_y)
    result_table[i,14] <- quantile(log(x),0.25)
    result_table[i,15] <- quantile(log(y),0.25)
  }
  
  # H. Provide some readable column names...    
  colnames(result_table) <- c("Taxum", 
                              "p value", 
                              "min_nr_outliers",
                              "max_nr_outliers",
                              "outliers_0_group",
                              "outliers_1_group",
                              "median_0_group",
                              "median_1_group",
                              "median",
                              "IQR_log_0",
                              "IQR_log_1",
                              "IQR_log",
                              "nr_outliers_01_group",
                              "q25_0",
                              "q25_1")
  
  # I. Write the table to the desired output file.
  write.table(
    result_table,
    paste("C_Results\\30_DataAnalysis\\15_Wilcoxon\\",
          "Wilcoxon",
          substr(normalisedData,11,nchar(normalisedData)),
          ".csv", sep = ""),
    row.names = F, 
    sep = ",")
  return("done") # might be nice to know, that the function did its task.
}        


# J. Now You should tell the code, which data to read. Possible data are:
#   -) normalised_training_genus
#   -) normalised_training_go
#   -) normalised_training_ko

make_Wilconxon_Table("normalised_training_genus")
make_Wilconxon_Table("normalised_training_go")
make_Wilconxon_Table("normalised_training_ko")