library(tidyverse)
library(ggplot2)
library(data.table)
library(plotROC)
library(PRROC)
library(ROCit)
library(car)
library(Hmisc)
library(xtable)
library(cvTools)
library(caret)
library(OptimalCutpoints)

#########################################################################
#                                                                       #
#            Create Input to Ensemble Learning:                         #
#            From Genera Models without Clinical Data                   #
#            =========================================                  #
# The input to ensemble learning is a byproduct of the assessment       # 
# process, so this code is in large parts a copy of the assessment code.#
#########################################################################

# A. Set the working directory here:
setwd("E:/AlzBiom/01_DataAnalysis/A_BaselineAnalysis/02_/04_AlzbiomToPublish")

# A.1. Set the path to the output folder:
output_folder_for_data <- "C_Results\\50_EnsembleLearning\\"

# B. Read the data (here normalized data on genera and validation data):
Training_Data_Normalisiert   <- 
  fread("A_Data/02_1_ExtendedTrainingData/normalised_training_Genus.csv",
        header = T, stringsAsFactors = F)
Training_Data_Normalisiert   <- data.frame(Training_Data_Normalisiert)

Validation_Data_Normalisiert <- 
  fread("A_Data/02_2_ExtendedValidationData/normalised_validation_Genus.csv",
        header = T, stringsAsFactors = F)
Validation_Data_Normalisiert <- data.frame(Validation_Data_Normalisiert)

# C. Find the best model

# C.1. Firstly You have to tell where to find the data:
result_path   <- 
  paste(
    "C_Results\\40_StatisticalModeling\\15_GLM\\",
    "Genera\\Genera_withoutClinicalData\\",
    sep = ""
  )

# C.2. The overall information about the models is in the Result.text file.
model_results <- 
  read.table(file = paste(result_path,"Results.txt", sep = ""))

# C.3. This plot gives an impression of how (mean) accuracy developed with
# number of selected features (the mean was calculated taking all the 
# accuracy values gathered in the cross validation into account).
plot(model_results[,3],model_results[,2], 
     type = "h", lwd = 5, 
     xlab = "Number of Features", ylab = "Mean Accuracy")

# C.4. It's easy to find the best model.
model_nr <- which(model_results[,2] == max(model_results[,2]))
model_results[model_nr,]

number_of_features  <- model_results[model_nr,3]
index_of_best_model <- model_results[model_nr,1]

# C.5. Sometimes one finds by visual inspection of the former plot
# another promising model with fewer features. 
# Therefore one can select a model here:
# (in case of the genera data 47 was used once.)
select_another_model <- T
if(select_another_model == T){index_of_best_model <- 41} 

# D. Read the selected features according to the best model.
best_balance <- 
  read.table(file = 
               paste(result_path,
                     "Balance_",
                     index_of_best_model,
                     ".txt", 
                     sep = ""),
             header = T)
# D.1. Show it...
best_balance 

# D.2. Calculate the balance.
makeLogSum <- function(x){
  n <- length(x)
  return(sum(log(x))/n)
}
# D.2.i. Firstly for the training data
Training_NUM_BalanceComponents <- 
  Training_Data_Normalisiert[, colnames(Training_Data_Normalisiert) %in% 
                               filter(best_balance, Group == "NUM")$Taxa]

Training_DEN_BalanceComponents <- 
  Training_Data_Normalisiert[, colnames(Training_Data_Normalisiert) %in% 
                               filter(best_balance, Group == "DEN")$Taxa]

Training_BalanceResults <- 
  data.frame(matrix(ncol = 6, nrow = dim(Training_Data_Normalisiert)[1]))
Training_BalanceResults[,1] <- Training_Data_Normalisiert$outcome
Training_BalanceResults[,3] <- Training_Data_Normalisiert$Age
Training_BalanceResults[,4] <- Training_Data_Normalisiert$BMI
Training_BalanceResults[,5] <- as.factor(Training_Data_Normalisiert$APOE4)
Training_BalanceResults[,6] <- as.factor(Training_Data_Normalisiert$Sex)

for(i in 1:dim(Training_Data_Normalisiert)[1]){
  Training_BalanceResults[i,2] <-  
    makeLogSum(Training_NUM_BalanceComponents[i,]) - 
    makeLogSum(Training_DEN_BalanceComponents[i,])
}

colnames(Training_BalanceResults) <- 
  c("outcome","Balance","Age","BMI","APOE", "Sex")

# D.2.ii. Secondly for the validation data
# This is the first time, that validation data enter the process.
Validation_NUM_BalanceComponents <- 
  Validation_Data_Normalisiert[, colnames(Validation_Data_Normalisiert) %in% 
                                 filter(best_balance, Group == "NUM")$Taxa]

Validation_DEN_BalanceComponents <- 
  Validation_Data_Normalisiert[, colnames(Validation_Data_Normalisiert) %in% 
                                 filter(best_balance, Group == "DEN")$Taxa]

Validation_BalanceResults <- 
  data.frame(matrix(ncol = 6, nrow = dim(Validation_Data_Normalisiert)[1]))
Validation_BalanceResults[,1] <- Validation_Data_Normalisiert$outcome
Validation_BalanceResults[,3] <- Validation_Data_Normalisiert$Age
Validation_BalanceResults[,4] <- Validation_Data_Normalisiert$BMI
Validation_BalanceResults[,5] <- as.factor(Validation_Data_Normalisiert$APOE4)
Validation_BalanceResults[,6] <- as.factor(Validation_Data_Normalisiert$Sex)

for(i in 1:dim(Validation_Data_Normalisiert)[1]){
  Validation_BalanceResults[i,2] <-  
    makeLogSum(Validation_NUM_BalanceComponents[i,]) - 
    makeLogSum(Validation_DEN_BalanceComponents[i,])
}

colnames(Validation_BalanceResults) <- 
  c("outcome","Balance","Age","BMI","APOE", "Sex")

# E. Fit a glm using the features of the best model with the training data
# Sometimes it is interesting, to train the model twice:
# -) including the non-microbiome information about gender, age,...
# -) using the microbiome information only.
train_model_including_nonmicrobiom_information <- F
if(train_model_including_nonmicrobiom_information == T){
  model <- 
    glm(factor(outcome) ~  
          Balance + Age + APOE + BMI + Sex, 
        family = "binomial", data = Training_BalanceResults)
}else{
  model <- 
    glm(factor(outcome) ~  
          Balance, 
        family = "binomial", data = Training_BalanceResults)        
}

# F. Calculation of ROC curves
Training_predicts   <- 
  predict(model, type = "response")
Validation_predicts <- 
  predict(model, type = "response", 
          newdata = data.frame(Validation_BalanceResults))

# F.1. for training data
df_predictions_training  <-  
  data.frame(outcome = Training_BalanceResults$outcome, 
             pred = fitted(model))

optimal.cutpoint.Youden <- 
  optimal.cutpoints(X = "pred", 
                    status = "outcome", 
                    tag.healthy = 0,
                    methods = "Youden", 
                    data = df_predictions_training, 
                    pop.prev = NULL, 
                    control = control.cutpoints(), 
                    ci.fit = TRUE, 
                    conf.level = 0.95, 
                    trace = FALSE)
(out_01 <- optimal.cutpoint.Youden$Youden$Global$measures.acc$AUC)
write.table(
  df_predictions_training,
  paste(output_folder_for_data,
        "TrainingDataForEnsembleLearning_GeneraWithoutClinicalData.csv",
        sep = ""),
  sep = ";",
  row.names = F,
  quote = F)

# F.2. for validation data
df_predictions_validation <-  
  data.frame(outcome = Validation_BalanceResults$outcome, 
             pred = Validation_predicts)

optimal.cutpoint.Youden <- 
  optimal.cutpoints(X = "pred", 
                    status = "outcome", 
                    tag.healthy = 0,
                    methods = "Youden", 
                    data = df_predictions_validation, 
                    pop.prev = NULL, 
                    control = control.cutpoints(), 
                    ci.fit = TRUE, 
                    conf.level = 0.95, 
                    trace = FALSE)

(out_02 <- optimal.cutpoint.Youden$Youden$Global$measures.acc$AUC)
write.table(
  df_predictions_validation,
  paste(output_folder_for_data,
        "ValidationDataForEnsembleLearning_GeneraWithoutClinicalData.csv",
        sep = ""),
  sep = ";",
  row.names = F,
  quote = F)
