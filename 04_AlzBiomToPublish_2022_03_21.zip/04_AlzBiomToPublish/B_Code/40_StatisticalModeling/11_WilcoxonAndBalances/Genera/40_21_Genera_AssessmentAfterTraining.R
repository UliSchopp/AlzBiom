library(tidyverse)
library(ggplot2)
library(data.table)
library(plotROC)
library(PRROC)
library(ROCit)
library(car)
library(Hmisc)
library(xtable)
library(cvTools)
library(caret)
library(OptimalCutpoints)

#########################################################################
#                                                                       #
#            Assessing the trained models after                         #
#            feature selection                                          #
#            =========================================                  #
# In the model training step a sequence of models were defined by       #
# feature selection. Starting with n features in the first model        #
# the feature number is reduced one by one. At each step the selected   #
# features and the accuracy were written to protocol files.             #
# Now these protocols will be used.                                     #
#                                                                       #
# And sorry for the inconvenience: But for some reasons, we decided to  #
# create code for each type of data (genus, ko, go) separately.         #
#                                                                       #
# Optionally the glm can be fitted using the clinical and microbiome    #
# data or the microbiome data only (see section E).                     #
#                                                                       #
# Another option is to write information about the features included    #
# in the best model to a tex file.                                      #
#                                                                       #
# Several plots are delivered. Plots should be 'zommed' to              #
# full screen size in RStudio or RGui. Some of them need a bit of time. #
# Please be patient!                                                    #
#########################################################################

# A. Set the working directory here:
setwd("D:/AlzBiom/01_DataAnalysis/A_BaselineAnalysis/02_/04_AlzbiomToPublish")

# B. Read the data (here normalized data on genera and validation data):
Training_Data_Normalisiert   <- 
  fread("A_Data/02_1_ExtendedTrainingData/normalised_training_Genus.csv",
        header = T, stringsAsFactors = F)
Training_Data_Normalisiert   <- data.frame(Training_Data_Normalisiert)

Validation_Data_Normalisiert <- 
  fread("A_Data/02_2_ExtendedValidationData/normalised_validation_Genus.csv",
        header = T, stringsAsFactors = F)
Validation_Data_Normalisiert <- data.frame(Validation_Data_Normalisiert)

# C. Find the best model

# C.1. Firstly You have to tell where to find the data:
result_path   <- 
  paste(
    "C_Results\\40_StatisticalModeling\\15_GLM\\",
    "Genera\\Genera_withClinicalData\\",
    sep = ""
  )

# C.2. The overall information about the models is in the Result.text file.
model_results <- 
  read.table(file = paste(result_path,"Results.txt", sep = ""))

# C.3. This plot gives an impression of how (mean) accuracy developed with
# number of selected features (the mean was calculated taking all the 
# accuracy values gathered in the cross validation into account).
plot(model_results[,3],model_results[,2], 
     type = "h", lwd = 5, 
     xlab = "Number of Features", ylab = "Mean Accuracy")

# C.4. It's easy to find the best model.
model_nr <- which(model_results[,2] == max(model_results[,2]))
model_results[model_nr,]

number_of_features  <- model_results[model_nr,3]
index_of_best_model <- model_results[model_nr,1]

# C.5. Sometimes one finds by visual inspection of the former plot
# another promising model with fewer features. 
# Therefore one can select a model here:
# (in case of the genera data 47 was used once.)
select_another_model <- F
if(select_another_model == T){index_of_best_model <- 47} 

# D. Read the selected features according to the best model.
best_balance <- 
  read.table(file = 
               paste(result_path,
                     "Balance_",
                     index_of_best_model,
                     ".txt", 
                     sep = ""),
                           header = T)
# D.1. Show it...
best_balance 

# D.2. Optionally write the data to a tex file, if You want to. This file is
# written to the working directory.
write_to_tex_file <- T

if(write_to_tex_file == T){
  Balance_to_Print <- 
    best_balance 
  # make names readable:
  Balance_to_Print[,1] <- 
    sapply(Balance_to_Print[,1], FUN = function(x){substr(x,1,30)})
  
  write.table(print(xtable(Balance_to_Print)),
              file = "tab_BestBalance.tex",
              col.names = F, row.names = F, quote = F)
}

# D.3. Calculate the balance.
makeLogSum <- function(x){
  n <- length(x)
  return(sum(log(x))/n)
}
# D.3.i. Firstly for the training data
Training_NUM_BalanceComponents <- 
  Training_Data_Normalisiert[, colnames(Training_Data_Normalisiert) %in% 
                               filter(best_balance, Group == "NUM")$Taxa]

Training_DEN_BalanceComponents <- 
  Training_Data_Normalisiert[, colnames(Training_Data_Normalisiert) %in% 
                               filter(best_balance, Group == "DEN")$Taxa]

Training_BalanceResults <- 
  data.frame(matrix(ncol = 6, nrow = dim(Training_Data_Normalisiert)[1]))
Training_BalanceResults[,1] <- Training_Data_Normalisiert$outcome
Training_BalanceResults[,3] <- Training_Data_Normalisiert$Age
Training_BalanceResults[,4] <- Training_Data_Normalisiert$BMI
Training_BalanceResults[,5] <- as.factor(Training_Data_Normalisiert$APOE4)
Training_BalanceResults[,6] <- as.factor(Training_Data_Normalisiert$Sex)

for(i in 1:dim(Training_Data_Normalisiert)[1]){
  Training_BalanceResults[i,2] <-  
    makeLogSum(Training_NUM_BalanceComponents[i,]) - 
    makeLogSum(Training_DEN_BalanceComponents[i,])
}

colnames(Training_BalanceResults) <- 
  c("outcome","Balance","Age","BMI","APOE", "Sex")

# D.3.ii. Secondly for the validation data
# This is the first time, that validation data enter the process.
Validation_NUM_BalanceComponents <- 
  Validation_Data_Normalisiert[, colnames(Validation_Data_Normalisiert) %in% 
                                 filter(best_balance, Group == "NUM")$Taxa]

Validation_DEN_BalanceComponents <- 
  Validation_Data_Normalisiert[, colnames(Validation_Data_Normalisiert) %in% 
                                 filter(best_balance, Group == "DEN")$Taxa]

Validation_BalanceResults <- 
  data.frame(matrix(ncol = 6, nrow = dim(Validation_Data_Normalisiert)[1]))
Validation_BalanceResults[,1] <- Validation_Data_Normalisiert$outcome
Validation_BalanceResults[,3] <- Validation_Data_Normalisiert$Age
Validation_BalanceResults[,4] <- Validation_Data_Normalisiert$BMI
Validation_BalanceResults[,5] <- as.factor(Validation_Data_Normalisiert$APOE4)
Validation_BalanceResults[,6] <- as.factor(Validation_Data_Normalisiert$Sex)

for(i in 1:dim(Validation_Data_Normalisiert)[1]){
  Validation_BalanceResults[i,2] <-  
    makeLogSum(Validation_NUM_BalanceComponents[i,]) - 
    makeLogSum(Validation_DEN_BalanceComponents[i,])
}

colnames(Validation_BalanceResults) <- 
  c("outcome","Balance","Age","BMI","APOE", "Sex")

# D.4. It might be interesting to see the 2 x 2 balances
#  (training data versus validation data) x (group 0 versus group 1)
# in one diagram. Data are shown as box plots.
Training_BalanceResults   <- data.frame(Training_BalanceResults)
Validation_BalanceResults <- data.frame(Validation_BalanceResults)

Training_BalanceResults$Type   <- "Training"
Validation_BalanceResults$Type <- "Validation"
BalanceResults <- rbind(Training_BalanceResults, Validation_BalanceResults)

ggplot(BalanceResults, aes(x = as.factor(outcome), y = Balance)) + 
  geom_boxplot() +
  facet_wrap(~Type) +
  xlab("outcome")

# D.5. Plot the best features:
data_for_plot <-
  data.frame(outcome = Training_Data_Normalisiert$outcome,
           Training_NUM_BalanceComponents,
           Training_DEN_BalanceComponents,
           type = "Training")

tmp_data_for_plot <-
  data.frame(outcome = Validation_Data_Normalisiert$outcome,
             Validation_NUM_BalanceComponents,
             Validation_DEN_BalanceComponents,
             type = "Validation")

data_for_plot <- rbind(data_for_plot, tmp_data_for_plot)
rm("tmp_data_for_plot")

data_reshaped <- reshape2::melt(data_for_plot, 
                                id = c("outcome","type"))
rm("data_for_plot")
data_reshaped$variable <- as.vector(data_reshaped$variable)
data_reshaped$logValue <- log10(data_reshaped$value)
data_reshaped$combinedKey <- 
  paste(data_reshaped$type,data_reshaped$outcome)
head(data_reshaped)

# D.5.1. Plot of features in best model by outcome groups:
ggplot(data_reshaped, 
       aes(x = variable, 
           y = logValue,
           fill = factor(outcome))) + 
  geom_boxplot()  +
  facet_wrap(~variable, scale="free") +
  xlab("Feature") + 
  ylab("logarithm of normalized value") +
  labs(fill = "outcome") +
  ggtitle("Features of best model by outcome groups")

# D.5.2. Plot of features in best model by 
# outcome groups x training/validation:
ggplot(data_reshaped, 
       aes(x = variable, 
           y = logValue,
           fill = factor(combinedKey))) + 
  geom_boxplot()  +
  facet_wrap(~variable, scale="free") +
  xlab("Feature") + 
  ylab("logarithm of normalized value") +
  labs(fill = "data type and outcome") +
  ggtitle("Features of best model by data type and outcome groups")

# E. Fit a glm using the features of the best model with the training data
# Sometimes it is interesting, to train the model twice:
# -) including the non-microbiome information about gender, age,...
# -) using the microbiome information only.
train_model_including_nonmicrobiom_information <- T
if(train_model_including_nonmicrobiom_information == T){
  model <- 
    glm(factor(outcome) ~  
          Balance + Age + APOE + BMI + Sex, 
        family = "binomial", data = Training_BalanceResults)
}else{
  model <- 
    glm(factor(outcome) ~  
          Balance, 
        family = "binomial", data = Training_BalanceResults)        
}

# F. Calculation of ROC curves
Training_predicts   <- 
  predict(model, type = "response")
Validation_predicts <- 
  predict(model, type = "response", 
          newdata = data.frame(Validation_BalanceResults))

# F.1. for training data
df_predictions_training  <-  
  data.frame(outcome = Training_BalanceResults$outcome, 
                               pred = fitted(model))

optimal.cutpoint.Youden <- 
  optimal.cutpoints(X = "pred", 
                    status = "outcome", 
                    tag.healthy = 0,
                    methods = "Youden", 
                    data = df_predictions_training, 
                    pop.prev = NULL, 
                    control = control.cutpoints(), 
                    ci.fit = TRUE, 
                    conf.level = 0.95, 
                    trace = FALSE)
(out_01 <- optimal.cutpoint.Youden$Youden$Global$measures.acc$AUC)

# F.2. for validation data
df_predictions_validation <-  
  data.frame(outcome = Validation_BalanceResults$outcome, 
                               pred = Validation_predicts)

optimal.cutpoint.Youden <- 
  optimal.cutpoints(X = "pred", 
                    status = "outcome", 
                    tag.healthy = 0,
                    methods = "Youden", 
                    data = df_predictions_validation, 
                    pop.prev = NULL, 
                    control = control.cutpoints(), 
                    ci.fit = TRUE, 
                    conf.level = 0.95, 
                    trace = FALSE)
(out_02 <- optimal.cutpoint.Youden$Youden$Global$measures.acc$AUC)

# F.3. gather the results for the plot
df_predictions_training$Type   <- "Training"
df_predictions_validation$Type <- "Validation"
df_predictions <- rbind(df_predictions_training,
                        df_predictions_validation)

# F.4. plot it
ggplot(df_predictions, 
       aes(d = outcome, m = pred, color = Type)) + 
  geom_roc(n.cut = 0) +
  style_roc() + 
  geom_abline(slope = 1,
              intercept = 0, 
              color = "grey50") +
  ggtitle(paste("ROC Curves for best Genera model with",
                number_of_features,
                "features."),
          subtitle = 
            if(train_model_including_nonmicrobiom_information == T){
              "Clinial and microbiome information used."
            }else{
              "Only microbiome information used."
            }) +
  annotate(geom="text", 
           x=0.3, y=0.1, 
           label=paste("Training AUROC:", round(out_01[1],3)),
           color= "#F8766D",
           hjust = 0,
           size = 8) +
  annotate(geom="text", 
           x=0.3, y=0.0, 
           label=paste("Validation AUROC:", round(out_02[1],3)),
           color="#00BFC4",
           hjust = 0,
           size = 8) +
  theme(axis.text  =element_text(size=16),
        axis.title = element_text(size = 16),
        plot.title = element_text(size = 20),
        legend.text = element_text(size = 16),
        legend.title = element_text(size = 16))

# F.5. save it (to working directory)
ggsave(filename = 
         paste("ROC_CURVES_GENERA_",
               number_of_features,
               ".jpeg", sep = ""),
       plot = last_plot(),
       width = 26,
       height = 18,
       units = c("cm"))
