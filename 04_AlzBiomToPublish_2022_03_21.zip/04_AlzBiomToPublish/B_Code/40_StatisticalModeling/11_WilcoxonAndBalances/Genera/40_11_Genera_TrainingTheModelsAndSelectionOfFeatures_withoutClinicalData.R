library(tidyverse)
library(ggplot2)
library(data.table)
library(mlr)
library(Hmisc)
library(xtable)
library(sqldf)
library(mlr)

#########################################################################
#                                                                       #
#            Statistical Modeling with Balances in GLM                  #
#            after Wilcoxon Selection (without clinical data)           #
#            ================================================           #
# This code serves for the further feature selection using balances     #
# and logistic regression after appropriate preselection of features.   #
# Balance is a concept from the area of compositional data analysis.    #
# Loosely speaking it condenses the information from several variables  #
# (multivariate data structure) to one number (univariate data).        #
# This is useful for regression approaches.                             #
# But one has to deal with the selection of suitable features to be     #
# included in the balance. This is done in two steps:                   #
#   -) Firstly information from some preliminary explorative data       #
#      analysis is used for a preselection.                             #
#   -) Then a series models is tested. Step by step one feature is      #
#      removed from the model. All models are fitted and assessed by    #
#      cross validation on the training data. So only parts of the      #
#      training data are used for fitting or assessment in turn.        #
# The crucial point is that with a bunch of n features available        #
# n models are fitted and validated each lacking one feature.           #
# Only the best model and its features selection enters to the next     #
# step, in which (n-1) features are left resulting in the compare of    #
# (n-1) new models.                                                     #
#                                                                       #
# And sorry for the inconvenience: But for some reasons, we decided to  #
# create code for each type of data (genus, ko, go) separately          #
#                                                                       #
# There is another very similar code for training models                #
# with  the microbiome data and clinical data.                          #
#########################################################################

# A. Set the working directory here:
setwd("D:/AlzBiom/01_DataAnalysis/A_BaselineAnalysis/02_/04_AlzbiomToPublish")

# B. Read the data (here normalized data on genera):
Training_Data_Normalisiert   <- 
  fread("A_Data/02_1_ExtendedTrainingData/normalised_training_Genus.csv",
        header = T, 
        stringsAsFactors = F)

Training_Data_Normalisiert   <- 
  data.frame(Training_Data_Normalisiert)

wilcox_result_table          <- 
  fread(
    paste(
      "C_Results/30_DataAnalysis/15_Wilcoxon/",
      "Wilcoxon_training_Genus.csv",
      sep = ""),
    header = T, 
    stringsAsFactors = F
  )

wilcox_result_table          <- 
  data.frame(wilcox_result_table)

wilcox_result_table          <- 
  wilcox_result_table[order(wilcox_result_table[,2], decreasing = F),]

# C. This is the crucial pre-selection step!
selected_wilcox_result_table  <- filter(wilcox_result_table, 
                                        p.value <= 0.50 & 
                                          min_nr_outliers >= 1 &
                                          max_nr_outliers <= 5) 

# D. One should check the number of preselected features. 
# Something in the range of 50 to 100 might be feasible.
dim(selected_wilcox_result_table)

# E. Tell the code Your desired output path to intermediate results:
result_path <- 
  paste(
    "C_Results\\40_StatisticalModeling\\15_GLM\\",
    "Genera\\Genera_withoutClinicalData\\",
    sep = ""
  )

# F. Does the output folder exist? If not, create it!
answ <- dir.exists(result_path)
if(answ == F){
  dir.create(result_path)
}

# G. Now we want to create the balance with all the pre-selected features.
# The balance has to sides. To decide on which side to put a feature,
# use the relation of the feature's medians in the two outcome groups.
nr_of_balances_to_use <- dim(selected_wilcox_result_table)[1]

Data_reshaped <- reshape2::melt(Training_Data_Normalisiert, 
                                id = "outcome")
Data_reshaped$variable <- 
  as.vector(Data_reshaped$variable)
Data_reshaped$value    <- as.numeric(Data_reshaped$value)
# Some warning message might occur due to the fact, that there are some
# data fields, that are not numeric (like the "DNAID"). 
# Don't bother, in the calculation of balances only microbiome features 
# and the information about outcome is used! The same applies to the 
# plots.

Balance <- data.frame(Taxa = rep(NA, nr_of_balances_to_use),
                      Group = rep(NA, nr_of_balances_to_use))

for(i in 1:nr_of_balances_to_use){
  Balance[i,1] = selected_wilcox_result_table[i,1]
  x <- 
    filter(Data_reshaped, 
           variable == selected_wilcox_result_table$Taxum[i] & 
             outcome == 0)$value
  y <- 
    filter(Data_reshaped, 
           variable == selected_wilcox_result_table$Taxum[i] & 
             outcome == 1)$value
  z <- 
    filter(Data_reshaped, variable == selected_wilcox_result_table$Taxum[i])
  
  if(median(x) < median(y)){
    Balance[i,2] = "DEN"
  }else{
    Balance[i,2] = "NUM"
  }
}

# H. This chunk of code provides a plot showing the features (in fact 
# logarithms  of normalized numbers) split by outcome groups. 
# The subplots are ordered by Wilcoxon test's p-values.
# The code has to be adapted to the data due to the sometimes long features
# names. 
# The plot is not suited for publication. It is intended for checking the
# preselection 'on the fly'.

tmp <- filter(Data_reshaped, variable %in% Balance[,1])
sql_text <- 
  "select * from tmp join selected_wilcox_result_table on 
   tmp.variable = selected_wilcox_result_table.Taxum"
selected_data <- 
  sqldf(sql_text)
selected_data <- 
  selected_data[order(selected_data$p.value,decreasing = F),]
selected_data$short <- 
  sapply(selected_data$variable, FUN = function(x){substr(x,1,30)})
selected_data$facet_variable <- 
  factor(selected_data$p.value)
selected_data$logx           <- 
  log(selected_data$value)

ggplot(selected_data, 
       aes(x = short, 
           y = logx,
           fill = factor(outcome))) + 
  geom_boxplot()  +
  facet_wrap(~facet_variable, scale="free") +
  xlab("Feature") + 
  ylab("logarithm of normalized value") +
  labs(fill = "outcome")  

# I. Calculate the Balance.

# I.1. Some tiny little function:
makeLogSum <- function(x){
  n <- length(x)
  return(sum(log(x))/n)
}

# I.2. Select the columns from the table...
Training_NUM_BalanceComponents <- 
  Training_Data_Normalisiert[, colnames(Training_Data_Normalisiert) %in% 
                               filter(Balance, Group == "NUM")$Taxa]

Training_DEN_BalanceComponents <- 
  Training_Data_Normalisiert[, colnames(Training_Data_Normalisiert) %in% 
                               filter(Balance, Group == "DEN")$Taxa]

# I.3. Initialize the result matrix
Training_BalanceResults <- 
  matrix(ncol = 2, nrow = dim(Training_Data_Normalisiert)[1])
Training_BalanceResults[,1] <- Training_Data_Normalisiert$outcome

# I.4. Make the calculations
for(i in 1:dim(Training_Data_Normalisiert)[1]){
  Training_BalanceResults[i,2] <-  
    makeLogSum(Training_NUM_BalanceComponents[i,]) - 
    makeLogSum(Training_DEN_BalanceComponents[i,])
}

colnames(Training_BalanceResults) <- c("outcome","Balance")

# I.5. Plot Calculated Balances
# If the boxes do not overlap too much, it might be a promising 
# features preselection.
Training_BalanceResults   <- data.frame(Training_BalanceResults)

ggplot(Training_BalanceResults, aes(x = as.factor(outcome), y = Balance)) + 
  geom_boxplot() +
  xlab("outcome") 

# J. Train the models and make further feature selection!
f.model_data      <- data.frame(Training_BalanceResults)

# J.1. Define the learner function  
cv_model <- function(f.model_data, f.folds = 5, f.reps = 300){    
  logReg      <- makeLearner("classif.logreg", predict.type = "prob")
  Task        <- makeClassifTask(data = f.model_data, target = "outcome")
  logRegModel <- mlr::train(logReg, Task)
  kFold       <- makeResampleDesc(method = "RepCV", 
                                  folds  = f.folds, 
                                  reps   = f.reps, 
                                  stratify = TRUE)
  
  logRegResam <- resample(logReg, 
                          Task, 
                          resampling = kFold, 
                          measures = list(acc, fpr, fnr),
                          show.info = F)  
  
  return(logRegResam$aggr)
}

# J.2. Initialization (all pre-selected features in the balance)
model_balance <- Balance

# J.3. Create the results' text file.
fn <- paste(result_path,"Results.txt", sep = "")

# J.4. Check its existence of result file
if (file.exists(fn)) {
  #Delete file if it exists
  file.remove(fn)
}

#set.seed(1987)

for(k in 1:(dim(Balance)[1]-5)){
  
  cv_dotted_models <- function(i){
    dotted_model_balance           <- model_balance[-i,]
    
    n_DEN <- sum(dotted_model_balance$Group == "DEN")
    n_NUM <- sum(dotted_model_balance$Group == "NUM")
    
    if(min(n_DEN,n_NUM) == 0){return("abort: DEN or NUM is missing.")}
    
    
    Training_NUM_BalanceComponents <- 
      Training_Data_Normalisiert[, colnames(Training_Data_Normalisiert) %in% 
                                   filter(dotted_model_balance, Group == "NUM")$Taxa]
    Training_NUM_BalanceComponents <- 
      as.matrix(Training_NUM_BalanceComponents)
    
    Training_DEN_BalanceComponents <- 
      Training_Data_Normalisiert[, colnames(Training_Data_Normalisiert) %in% 
                                   filter(dotted_model_balance, Group == "DEN")$Taxa]
    Training_DEN_BalanceComponents <- as.matrix(Training_DEN_BalanceComponents)
    
    Training_BalanceResults <- 
      matrix(ncol = 2, nrow = dim(Training_Data_Normalisiert)[1])
    Training_BalanceResults[,1] <- 
      Training_Data_Normalisiert$outcome
    
    for(i in 1:dim(Training_Data_Normalisiert)[1]){
      Training_BalanceResults[i,2] <-  
        makeLogSum(Training_NUM_BalanceComponents[i,]) - 
        makeLogSum(Training_DEN_BalanceComponents[i,])
    }
    
    Training_BalanceResults           <- 
      data.frame(Training_BalanceResults)
    colnames(Training_BalanceResults) <- 
      c("outcome","Balance")
    Training_BalanceResults$outcome   <- 
      factor(Training_BalanceResults$outcome) 
    return(cv_model(Training_BalanceResults))
  }
  
  results <- sapply(1:dim(model_balance)[1], cv_dotted_models)
  
  if(results[1] == "abort: DEN or NUM is missing."){break}
  
  # Deleted will be the feature, that gave the best model
  # WHEN IT WAS DELETED IN THE MODELS UNDER REVIEW!
  throw_way     <- 
    max(which(results[1,] == max(results[1,]))) 
  print(max(results[1,]))
  
  write.table(t(c(k,
                  round(max(results[1,]),5),
                  dim(results)[2]-1)),
              file = paste(result_path,"Results.txt", sep = ""),
              append = T,
              row.names = F,
              col.names = F)
  model_balance <- model_balance[-throw_way,]
  write.table(model_balance,
              file = paste(result_path,"Balance_",k,".txt", sep = ""),
              row.names = F)
  
}
